import { Router } from 'express';
import { body, param, validationResult } from 'express-validator';
import pool from '../db.js';
const router = Router();
function handleValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  next();
}
router.post('/',
  [body('title').trim().notEmpty().withMessage('title is required'), body('description').optional().isString()],
  handleValidation,
  async (req, res, next) => {
    try {
      const { title, description = '' } = req.body;
      const [result] = await pool.execute('INSERT INTO tasks (title, description) VALUES (?, ?)', [title, description]);
      const [rows] = await pool.execute('SELECT * FROM tasks WHERE id = ?', [result.insertId]);
      res.status(201).json(rows[0]);
    } catch (err) { next(err); }
  }
);
router.get('/', async (req, res, next) => {
  try { const [rows] = await pool.execute('SELECT * FROM tasks ORDER BY id DESC'); res.json(rows); }
  catch (err) { next(err); }
});
router.get('/:id', [param('id').isInt()], handleValidation, async (req, res, next) => {
  try { const [rows] = await pool.execute('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Task not found' });
    res.json(rows[0]); } catch (err) { next(err); }
});
router.put('/:id',
  [param('id').isInt(), body('title').trim().notEmpty(), body('description').optional().isString()],
  handleValidation,
  async (req, res, next) => {
    try {
      const { title, description = '' } = req.body;
      const [result] = await pool.execute('UPDATE tasks SET title = ?, description = ? WHERE id = ?', [title, description, req.params.id]);
      if (result.affectedRows === 0) return res.status(404).json({ error: 'Task not found' });
      const [rows] = await pool.execute('SELECT * FROM tasks WHERE id = ?', [req.params.id]);
      res.json(rows[0]);
    } catch (err) { next(err); }
  }
);
router.delete('/:id', [param('id').isInt()], handleValidation, async (req, res, next) => {
  try {
    const [result] = await pool.execute('DELETE FROM tasks WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Task not found' });
    res.status(204).send();
  } catch (err) { next(err); }
});
export default router;
