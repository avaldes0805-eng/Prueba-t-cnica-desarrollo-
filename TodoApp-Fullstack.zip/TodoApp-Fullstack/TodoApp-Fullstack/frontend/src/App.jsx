import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './app.css';
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';
function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [editing, setEditing] = useState(null);
  const [errors, setErrors] = useState('');
  async function fetchTasks() { const { data } = await axios.get(`${API_URL}/tasks`); setTasks(data); }
  useEffect(() => { fetchTasks().catch(console.error); }, []);
  async function handleCreate(e) {
    e.preventDefault(); setErrors('');
    try { const { data } = await axios.post(`${API_URL}/tasks`, { title, description });
      setTasks(prev => [data, ...prev]); setTitle(''); setDescription('');
    } catch (err) {
      if (err.response?.data?.errors) setErrors(err.response.data.errors.map(e => e.msg).join(', '));
      else setErrors('Error creating task');
    }
  }
  async function handleUpdate(id, newTitle, newDescription) {
    setErrors('');
    try { const { data } = await axios.put(`${API_URL}/tasks/${id}`, { title: newTitle, description: newDescription });
      setTasks(prev => prev.map(t => (t.id === id ? data : t))); setEditing(null);
    } catch (err) {
      if (err.response?.data?.errors) setErrors(err.response.data.errors.map(e => e.msg).join(', '));
      else setErrors('Error updating task');
    }
  }
  async function handleDelete(id) { try { await axios.delete(`${API_URL}/tasks/${id}`); setTasks(prev => prev.filter(t => t.id !== id)); } catch {} }
  return (<div className="container"><div className="card"><h1>TodoApp</h1><p className="badge">Fullstack • React + Express</p>
    <form onSubmit={handleCreate}><div className="label">Título</div>
      <input className="input" placeholder="Ej: Entregar informe" value={title} onChange={e => setTitle(e.target.value)} />
      <div className="label">Descripción</div>
      <textarea className="input" placeholder="Detalles opcionales..." value={description} onChange={e => setDescription(e.target.value)} />
      {errors && <div className="error">{errors}</div>}<button className="button primary" type="submit">Agregar</button>
    </form>
    <div className="list">{tasks.map(task => (<div key={task.id} className="row">
      {editing === task.id ? (<EditRow task={task} onCancel={() => setEditing(null)} onSave={(t, d) => handleUpdate(task.id, t, d)} />) :
      (<><div><strong>{task.title}</strong></div><div>{task.description || <em>Sin descripción</em>}</div>
        <div className="actions"><button className="button secondary" onClick={() => setEditing(task.id)}>Editar</button>
          <button className="button" onClick={() => handleDelete(task.id)}>Eliminar</button></div></>)} </div>))}</div>
    <div className="footer">API: <code>{API_URL}</code></div></div></div>);
}
function EditRow({ task, onCancel, onSave }) {
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || '');
  return (<>
    <input className="input" value={title} onChange={e => setTitle(e.target.value)} />
    <input className="input" value={description} onChange={e => setDescription(e.target.value)} />
    <div className="actions"><button className="button secondary" onClick={onCancel}>Cancelar</button>
      <button className="button primary" onClick={() => onSave(title, description)}>Guardar</button></div></>);
}
export default App;
